jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 twokey in the list

sap.ui.require([
	"sap/ui/test/Opa5",
	"app/twokey/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"app/twokey/test/integration/pages/App",
	"app/twokey/test/integration/pages/Browser",
	"app/twokey/test/integration/pages/Master",
	"app/twokey/test/integration/pages/Detail",
	"app/twokey/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "app.twokey.view."
	});

	sap.ui.require([
		"app/twokey/test/integration/MasterJourney",
		"app/twokey/test/integration/NavigationJourney",
		"app/twokey/test/integration/NotFoundJourney",
		"app/twokey/test/integration/BusyJourney"
	], function () {
		QUnit.start();
	});
});